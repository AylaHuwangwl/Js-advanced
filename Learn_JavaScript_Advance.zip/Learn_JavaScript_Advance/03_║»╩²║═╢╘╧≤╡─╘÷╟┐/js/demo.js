// 给整个script开启严格模式
"use strict"

