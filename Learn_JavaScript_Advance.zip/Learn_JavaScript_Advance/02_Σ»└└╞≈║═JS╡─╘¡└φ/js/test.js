console.log("test")
console.log("defer script")

var message = "test message"

// debugger

// 总结二: 在defer代码中DOM Tree已经构建完成
var boxEl = document.querySelector(".box")
console.log(boxEl)
