console.log("demo")

console.log(message)
